'use client'

import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { Button } from "@/components/ui/button"

export function Navigation() {
  const { data: session } = useSession()

  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="text-xl font-bold">
          Real Estate Platform
        </Link>
        <div className="space-x-4">
          <Link href="/properties">
            <Button variant="ghost">Properties</Button>
          </Link>
          {session ? (
            <>
              <span className="mr-4">Welcome, {session.user?.name}</span>
              <Button variant="outline" onClick={() => signOut()}>Sign Out</Button>
            </>
          ) : (
            <Link href="/auth/signin">
              <Button>Sign In</Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  )
}

